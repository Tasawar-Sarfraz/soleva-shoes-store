/**
 * @license
 * Cesium - https://github.com/CesiumGS/cesium
 * Version 1.146.0
 *
 * Copyright 2011-2022 Cesium Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Columbus View (Pat. Pend.)
 *
 * Portions licensed separately.
 * See https://github.com/CesiumGS/cesium/blob/main/LICENSE.md for full licensing details.
 */

import{S as l,g as n,l as t,v as p}from"./chunk-GWE2HRAQ.js";function o(e,i){return n(i)&&(e=l.unpack(e,i)),e._ellipseGeometry._center=t.clone(e._ellipseGeometry._center),e._ellipseGeometry._ellipsoid=p.clone(e._ellipseGeometry._ellipsoid),l.createGeometry(e)}var r=o;export{r as default};
